﻿using UnityEngine;
using System.Collections;

public class DoorTest : MonoBehaviour {
	private Collider2D col;
	private bool doorOpen;
	private Quaternion target = Quaternion.Euler(0,90,0);
	private Vector3 closePos;
	private Vector3 openPos;
	private float currentTime;
	private float rotSpeed = 3;
	private float slideSpeed = .5f;
	public Transform door;
	// Use this for initialization
	void Start () {
		col = GetComponent<Collider2D>();
		closePos = door.position;
		openPos = door.position + new Vector3(-0.35f,0,0);
	}
	
	// Update is called once per frame
	void Update () {
		if(doorOpen){
			door.rotation = Quaternion.Slerp(door.rotation, target, Time.deltaTime * rotSpeed);
			door.position = Vector3.Slerp(closePos,openPos,(Time.time-currentTime)/slideSpeed);
		}
		if(!doorOpen){
			door.rotation = Quaternion.Slerp(door.rotation, Quaternion.identity, Time.deltaTime * rotSpeed);
			door.position = Vector3.Slerp(openPos,closePos,(Time.time-currentTime)/slideSpeed);
		}
	}
	
	void OnTriggerEnter2D(Collider2D other) {
        doorOpen = true;
		currentTime = Time.time;
    }
	
	void OnTriggerExit2D(Collider2D other){
		doorOpen = false;
		currentTime = Time.time;
	}
}
