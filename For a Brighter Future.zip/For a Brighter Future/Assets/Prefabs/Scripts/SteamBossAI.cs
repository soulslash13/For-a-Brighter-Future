﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SteamBossAI : MonoBehaviour {
	private Rigidbody2D rb;
	private int frameCount = 0;
	private Animator ani;
	private int dir = 0;
	private int attackTime;
	private int telegraphs = 0;
	private int attackStarted = 0;
	private int health;
	private int deathCd;
	private bool attacking = false;
	public int speed;
	public Animator arms;
	public GameObject jet1;
	public GameObject jet2;
	public GameObject door;
	public SpriteRenderer spriteImage;
	public Sprite health1;
	public Sprite health2;
	public Sprite health3;
	public Sprite health4;
	public Sprite health5;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D>();
		door.SetActive (false);
		health = 15;
		deathCd = 20;
		ani = GetComponent<Animator>();
		jet1.SetActive(false);
		jet2.SetActive(false);
		attackTime = Random.Range(90,120);
	}
	
	// Update is called once per frame
	void Update () {
		checkDead();
		checkDie ();
		if (notDead()) {
			updateHealth ();
			if (frameCount % 90 == 0) {
				dir = Random.Range (0, 2);
			}
			if (dir == 0) {
				rb.AddForce (transform.right * speed);
				ani.SetBool ("left", false);
			}
			if (dir == 1) {
				rb.AddForce (transform.right * speed * -1);
				ani.SetBool ("left", true);
			}
			if (frameCount % attackTime == 0 && !attacking) {
				arms.SetTrigger ("Attack");
				attackTime += 60;
				telegraphs++;
			}
			if (attacking) {
				arms.SetTrigger ("Attack");
			}
			if (telegraphs >= 4) {
				jet1.SetActive (true);
				jet2.SetActive (true);
				attackStarted = frameCount;
				telegraphs = 0;
				attacking = true;
			}
			if (frameCount - attackStarted == 240 && attacking) {
				attackTime = Random.Range (90, 120);
				jet1.SetActive (false);
				jet2.SetActive (false);
				attacking = false;
			}
			frameCount++;
		}
	}

	void updateHealth(){
		if (health > 12) {
			spriteImage.sprite = health5;
		} else if (health > 9) {
			spriteImage.sprite = health4;
		} else if (health > 6) {
			spriteImage.sprite = health3;
		} else if (health > 3) {
			spriteImage.sprite = health2;
		}  else {
			spriteImage.sprite = health1;
		}
	}

	bool notDead(){
		if (health > 0) {
			return true;
		} else {
			return false;
		}
	}
		
			
	void checkDead(){
		if (health < 1) {
			ani.SetTrigger ("boom");
			deathCd -= 1;
		}
	}

	void checkDie(){
		if (deathCd < 1) {
			door.SetActive (true);
			Destroy(gameObject);
		}
	}

	private void OnTriggerEnter2D(Collider2D other)	//determines if the player has entered a hit box, and then what it was
	{
		if (other.tag == "gear") {	//boss was hit by gear
			health -= 1;
			print("SteamBoss HP: " + health);
		}
	}
}
