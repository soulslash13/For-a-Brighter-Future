﻿using UnityEngine;
using System.Collections;

public class Player : MovingObj {
	private int hp;
	private int cd;
	private int dmgCd;
	private bool loading;
	private Rigidbody2D rb2;
	public Animator animator;
	public GameObject gear;
	public GameObject forcefield;

	public override void Start () {	//begins your short life
		hp = 6;
		cd = 0;
		dmgCd = 0;
		loading = true;
		forcefield.SetActive (false);
		rb2 = GetComponent<Rigidbody2D>();
		animator = GetComponent<Animator>();
		gear.SetActive(false);
		base.Start();
	}
	
	public int getHealth(){	//returns hp
			return hp;
	}
	
	void Update () {	//Update is called once per frame
		if(GameManager.instance.isLoading()){
			loading = true;
		}else{
			loading = false;
		}
		if(!loading){
			if(cd > 0){
				cd--;
			}
			makeField ();
			if(dmgCd > 0){
				dmgCd--;
			}
			tryMove();
			tryAttack();
		}
	}
	
	public void takeDamage(int amt){	//damages player
		hp = hp - amt;
	}

	private void makeField(){
		if(Input.GetKey (KeyCode.E)){
			forcefield.SetActive(true);
		}else{
			forcefield.SetActive(false);
		}
	}
	public void addHp(int amt){ 		//adds HP
		hp = hp + amt;
		if(hp > 6){
			hp = 6;
		}
	}
	
	private void tryAttack(){	//attempts to attack
		
		if(Input.GetKey("space") && cd <= 0){
			animator.SetTrigger("attack");
			gear.SetActive(true);
			Instantiate(gear, transform.position, transform.rotation);
			gear.SetActive(false);
			cd = 30;
		}
	}
	
	public int getDirection(){
		if(animator.GetBool("movingUp")){
			return 0;
		}else if(animator.GetBool("movingDown")){
			return 2;
		}else if(animator.GetBool("movingLeft")){
			return 3;
		}else if(animator.GetBool("movingRight")){
			return 1;
		}
		return 0;
	}
	
	private void tryMove(){																				//attempts to take user input and move
		float moveH = (int)Input.GetAxisRaw("Horizontal");	//horizontal keyboard input
		float moveV = (int)Input.GetAxisRaw("Vertical");	//vertical keyboard input
			
		animatePlayer(moveH, moveV);
		base.Move(moveH, moveV, 10f);
	}
	
	public bool checkIfGameOver(){																		//checks if your dead
		if(hp < 1){
			return true;
		}
		return false;
	}
	
	private void OnTriggerEnter2D(Collider2D other)	//determines if the player has entered a hit box, and then what it was
    {
		if (other.tag == "FactoryExit") {	//player touched the factory exit door
			GameManager.instance.setLoadTime (120);
			GameManager.instance.setLevel (2);
			base.quickMove ((0f - 0.33f), 25.4f);
		} else if (other.tag == "FactoryEntrance") {	//player entered the factory entrance door
			GameManager.instance.setLoadTime (120);
			GameManager.instance.setLevel (1);
			base.quickMove (.075f, -2f);
		} else if (other.tag == "caveEntrance") {
			GameManager.instance.setLoadTime (120);
			GameManager.instance.setLevel (2);
			base.quickMove (22, 6);
		} else if (other.tag == "steambossEntrance") {
			GameManager.instance.setLoadTime (120);
			base.quickMove (22, -13);
		} else if (other.tag == "jet") {
			if (dmgCd < 1) {
				hp -= 1;
				dmgCd = 30;
			}
		} else if (other.tag == "forestTransition") {
			GameManager.instance.setLoadTime (120);
			base.quickMove (25, 36);
		} else if (other.tag == "darkForestTransition") {
			GameManager.instance.setLoadTime (120);
			base.quickMove(54, 25);
		} else if (other.tag == "forestTransitionBack") {
			GameManager.instance.setLoadTime (120);
			base.quickMove(36, 24);
		} else if (other.tag == "villageTransition") {
			GameManager.instance.setLoadTime (120);
			base.quickMove(82, 29);
		} else if (other.tag == "darkForestTransitionBack") {
			GameManager.instance.setLoadTime (120);
			base.quickMove(66, 34);
		}
    }
	
	private void animatePlayer(float moveH, float moveV){												//animates player
		if(moveH != 0){  //checks horizontal position
			if(moveH > 0){	//checks if moving Right
				//sets direction
				animator.SetBool("movingUp", false);
				animator.SetBool("movingLeft", false);
				animator.SetBool("movingDown", false);
				animator.SetBool("movingRight", true);
				//move animation
				animator.SetTrigger("moveRight");
			}
			else if(moveH < 0){ //checks if moving Left
				//sets direction
				animator.SetBool("movingUp", false);
				animator.SetBool("movingLeft", true);
				animator.SetBool("movingDown", false);
				animator.SetBool("movingRight", false);
				//move animation
				animator.SetTrigger("moveLeft");
			}
		}
		else if(moveV != 0){ //checks if moving vertically
			if(moveV > 0){	//checks if moving up
				//sets direction
				animator.SetBool("movingUp", true);
				animator.SetBool("movingLeft", false);
				animator.SetBool("movingDown", false);
				animator.SetBool("movingRight", false);
				//move animation
				animator.SetTrigger("moveUp");		
				
			}
			else if(moveV < 0){ //checks if moving down
				//sets direction
				animator.SetBool("movingUp", false);
				animator.SetBool("movingLeft", false);
				animator.SetBool("movingDown", true);
				animator.SetBool("movingRight", false);
				//move animation
				animator.SetTrigger("moveDown");
				
			}
		}
	}
}