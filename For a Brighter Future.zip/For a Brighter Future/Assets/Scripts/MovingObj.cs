﻿using UnityEngine;
using System.Collections;

public class MovingObj : MonoBehaviour {
	
	
	public LayerMask Entities;
    private BoxCollider2D boxCollider;
    private Rigidbody2D rb;

	// Use this for initialization
	public virtual void Start () {
        boxCollider = GetComponent<BoxCollider2D>();
        rb = GetComponent<Rigidbody2D>();
	}
	
	//find the RigidBody2D component
	public void setRigidBody(Rigidbody2D newRb){
		rb = newRb;
	}
	
	//basic movement of an object
	protected void Move(float x, float y, float newThrust){
			float thrust = newThrust;
			float stop = 0f;
			
			if(x > 0){ //horizontal thrust
				rb.AddForce(transform.right * thrust);
			}else if(x < 0){
				rb.AddForce(transform.right * -thrust);
			}
			if(y > 0){	//vertical thrust
				rb.AddForce(transform.up * thrust);
			}else if(y < 0){
				rb.AddForce(transform.up * -thrust);
			}
	}
	//teleportation of an object. Moves to given coordinate
	public void quickMove(float x, float y){		
		Vector3 newpos = new Vector3(x, y);
		rb.MovePosition(newpos);
	}
	
	//returns objects current x value
	public float getX(){	
		float x = GetComponent<Rigidbody2D>().position.x;
		return x;
	}
	
	//returns objects current y value
	public float getY(){
		float y = GetComponent<Rigidbody2D>().position.y;
		return y;
	}
}
