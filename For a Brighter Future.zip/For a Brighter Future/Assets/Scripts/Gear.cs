﻿using UnityEngine;
using System.Collections;

public class Gear : MonoBehaviour {
private Transform tf;
public float speed;
public int time;
public float rotSpeed;
private int dir; //0 up, 1 right, 2 down, 3 left
public Player player;

	// Use this for initialization
	void Start () {
		tf = GetComponent<Transform>();
		getDirection();
		time = 0;
	}
	
	private void getDirection(){
		dir = player.getDirection();
	}
	
	private void OnTriggerEnter2D(Collider2D other)	//determines if the player has entered a hit box, and then what it was
    {
       if(other.tag == "turret"){
		   turret turret = other.GetComponentInParent<turret>();
		   turret.takeDamage(1);
		   Destroy(gameObject);
	   }
	   if(other.tag == "wall"){
		   Destroy(gameObject);
		   print("Hit wall");
	   }
		if (other.tag == "steamBoss") {
			Destroy (gameObject);
		}
	}
	
	// Update is called once per frame
	void Update () {
		time++;
		tf.Rotate(0,0,rotSpeed);
		if(dir==0){
			tf.position += Vector3.up *speed;
		}
		if(dir==1){
			tf.position += Vector3.right *speed;
		}
		if(dir==2){
			tf.position += Vector3.up *-speed;
		}
		if(dir==3){
			tf.position += Vector3.right *-speed;
		}
		if(time > 180){
			Destroy(gameObject);
		}
	}
}
