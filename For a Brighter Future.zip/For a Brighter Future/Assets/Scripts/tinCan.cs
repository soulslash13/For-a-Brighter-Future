﻿using UnityEngine;
using System.Collections;

public class tinCan : MovingObj {
	private float bulletForce;		//force to push bullet along path
	private float speedAccel;		//rate at which speed drop occurs
	private GameObject foundTank; 	//its a tank but you cant use it as a tank
	public turret tank;				//object firing
	private Rigidbody2D rb2;		//physics;)
	private float moveV;			//vertical direction
	private float moveH;			//horizontal direction
	private Vector3 targetDir;
	private int liveTime;
	
	/**
		Directional Values supplied from shooting tank :
		1 = up
		2 = down
		3 = right
		4 = left
	**/
	// Use this for initialization
	public override void Start() {
		foundTank = findClosestTank();
		tank = foundTank.GetComponentInParent<turret>();
		targetDir = tank.aimBullet();
		rb2 = GetComponent<Rigidbody2D>();
		base.setRigidBody(rb2);
		bulletForce = 10f;
		liveTime = 180;
	}
	
	// Update is called once per frame
	void Update () {
		checkIfDead();
		liveTime --;
		transform.LookAt(transform.position + new Vector3(0,0,1), targetDir * -1);
		base.Move(0,1,10f);
	}
	
	private void OnTriggerEnter2D(Collider2D other)
    {
	   if(other.tag == "wall"){
		   Destroy(gameObject);
		   print("Hit wall");
	   }
	   if(other.tag == "Player"){
		   Player player = other.GetComponentInParent<Player>();
		   player.takeDamage(1);
		   print("Hit player");
		   Destroy(gameObject);
	   }
	}
	
	void checkIfDead(){
		if(liveTime <= 0){
			Destroy(gameObject);
		}
	}
	
	GameObject findClosestTank(){
		GameObject[] tanks;
		tanks = GameObject.FindGameObjectsWithTag("turret");
		GameObject myTank = null;
		float distance = Mathf.Infinity;
		Vector3 myPos = transform.position;
		
		foreach(GameObject thisTank in tanks){
			Vector3 newDistance = thisTank.transform.position - myPos;
			float thisDistance = newDistance.sqrMagnitude;
				if(thisDistance < distance){
					myTank = thisTank;
					distance = thisDistance;
				}
		}
		return myTank;
	}
}
