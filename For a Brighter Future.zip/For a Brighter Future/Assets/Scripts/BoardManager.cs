﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
public class BoardManager : MonoBehaviour {
	public static BoardManager instance = null;
	public GameObject map;				//map object to display maps
	public Sprite zone1Map; 			//dessert map
	public Sprite zone1Cave;			//Dessert Cave
	public Sprite zone1BossRoom; 		//dessert Boss Room
	public GameObject factoryInside; 	//figure it out
	public GameObject zone1Outside;		//Fences, and the random cacti
	public GameObject zone1Main;		//zone1 Main map and map objects
	public GameObject turret;			//turrets to spawn
	private bool levelChanged;			//tells if the level was changed
	private int level;					//current level, tells game what map to load along with what enemies to load.
	
	// Use this for initialization
	void Start (){
		if (instance == null)	
            instance = this;
        else if (instance != null)
            Destroy(gameObject);
		
        DontDestroyOnLoad (gameObject);
		levelChanged = true;
		
		
		level = 1;
		hideSpawns();
		levelChanged = true;
		factoryInside = GameObject.Find("FactoryInside");
		zone1Main = GameObject.Find("main");
		turret.SetActive(false);
		map.GetComponent<SpriteRenderer>().sprite = zone1Map;
	}
	
	// Update is called once per frame
	void Update () {
		level = GameManager.instance.getLevel();
		if(levelChanged){
			levelChanged = false;
			switch(level){	//tells the game what background to load and how many enemies it should create.
				case 1: factoryInside.SetActive(true);
						clearEnemies();
						zone1Main.SetActive(false);
						zone1Outside.SetActive(false);
						map.SetActive(false);
						break;
				case 2: factoryInside.SetActive(false);
						clearEnemies();
						zone1Main.SetActive(true);
						zone1Outside.SetActive(true);
						map.GetComponent<SpriteRenderer>().sprite = zone1Map;
						map.SetActive(true);
						spawnEnemies();
						break;
				default:
						clearEnemies();
						factoryInside.SetActive(true);
						zone1Main.SetActive(false);
						zone1Outside.SetActive(false);
						map.SetActive(false);
						break;
			}
		}
	}
	
	public void changeLevel(){
		levelChanged = true;
	}
	
	void spawnEnemies(){
		GameObject[] spawnTanks;
		//GameObject[] spawnEnemies;
		float spawnX;
		float spawnY;
		spawnTanks = GameObject.FindGameObjectsWithTag("tankSpawn");
		foreach(GameObject thisSpawn in spawnTanks){
			turret.SetActive(true);
			spawnX = thisSpawn.transform.position.x;
			spawnY = thisSpawn.transform.position.y;
			Instantiate(turret, new Vector3(spawnX, spawnY , .5f), Quaternion.identity);
			turret.SetActive(false);
		}
	}
	
	void clearEnemies(){
		GameObject[] tanks;
		tanks = GameObject.FindGameObjectsWithTag("turret");
		foreach(GameObject thisTank in tanks){
			Destroy(thisTank);
		}
	}
	
	void hideSpawns(){
		GameObject[] spawns;
		spawns = GameObject.FindGameObjectsWithTag("tankSpawn");
		foreach(GameObject thisSpawn in spawns){
			thisSpawn.GetComponent<SpriteRenderer>().sprite = null;
		}
	}
}