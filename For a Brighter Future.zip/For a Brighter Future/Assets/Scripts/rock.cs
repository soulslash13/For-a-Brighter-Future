﻿using UnityEngine;
using System.Collections;

public class rock : MonoBehaviour {
	public Player player;
	private Rigidbody2D rb;
	private int direction;
	private bool inRange;
	private bool canMove;
	private int cd;
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D>();
		inRange = false;
		cd = 0;
	}
	
	// Update is called once per frame
	void Update () {
		if(cd > 0){
			cd--;
		}
		if(cd < 1 && canMove){
			canMove = false;
		}
		if (canMove || inRange) {
			if (Input.GetKey (KeyCode.E)) {
				direction = player.getDirection ();
				move ();
			}
		}
	}
	
	public void OnTriggerEnter2D(Collider2D other){
		if(other.tag == "Player"){
			print("rock is touching player");
			inRange = true;
			canMove = true;
		}
	}
	
	public void OnTriggerExit2D(Collider2D other){
		if(other.tag == "Player"){
			inRange = false;
			cd = 30;
			print("no longer touching player");
		}
	}
	/**
	up = 0
	down = 2
	left = 3
	right = 1
	**/
	
	protected void move(){
			float thrust = 10f;
			float stop = 0f;
			
			if(direction == 1){ //horizontal thrust
				rb.AddForce(transform.right * thrust);
			}else if(direction == 3){
				rb.AddForce(transform.right * -thrust);
			}
			if(direction == 0){	//vertical thrust
				rb.AddForce(transform.up * thrust);
			}else if(direction == 2){
				rb.AddForce(transform.up * -thrust);
			}
	}
}
