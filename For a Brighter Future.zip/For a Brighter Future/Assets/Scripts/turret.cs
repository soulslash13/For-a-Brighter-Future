﻿using UnityEngine;
using System.Collections;

public class turret : MonoBehaviour {
	private Rigidbody2D rb; 	//rigidBody component
	private Animator animator;	//animator component
	public GameObject bullet;	//pew
	public GameObject smoke;	//smoky
	public Transform target;    //target
	private int hp;				//health
	private int attackCd;		//coolDown for attacking
	private int dmg;			//damage to be dealt
	private int dmgCd;			//coolDown to take damage
	private int dying;			//you're quickly losing life
	private float targetX;		//player's x
	private float targetY;		//player's y
	public int fireRate;
	
	void Start () {	//if you don't understand, you shouldn't be looking at this			
		target = GameObject.FindGameObjectWithTag("Player").transform;
		bullet.SetActive(false);
		smoke.SetActive(false);
        animator = GetComponent<Animator>();
		rb = GetComponent<Rigidbody2D>();
		dying    =  40;
		hp       = 	4;
		dmg      =	 1;
		attackCd = 	 0;
		dmgCd    = 	 0;
	}
	
	
	void Update (){		// Update is called once per frame
		if(GameManager.instance.isLoading()){
		}else{
			targetX = GameObject.FindGameObjectWithTag("Player").transform.position.x;
			targetY = GameObject.FindGameObjectWithTag("Player").transform.position.y;
			checkIfDead();
			if(attackCd > 0){
				attackCd--;
			}
			if(dying > 39){
				aim();
				tryAttack();
			}
		}
	}
	
	public Vector3 aimBullet(){
		Vector3 targetDir = transform.position-target.position;
		return targetDir;
	}
	void aim(){	//aim the barrel
	
		Vector3 targetDir = transform.position-target.position;
		transform.LookAt(transform.position + new Vector3(0,0,1), targetDir * -1);
		tryAttack();
    }
	
	public void takeDamage(int amt){
		hp--;
	}
	
	public bool playerInRange(){
		if(Mathf.Abs(targetX - rb.transform.position.x) < 7){
			if(Mathf.Abs(targetY - rb.transform.position.y) < 5){
				return true;
			}
			return false;
		}
		return false;
	}
	
	void tryAttack(){	//Attempts attacking the player
		if(attackCd == 0 && playerInRange()){
			attackCd = fireRate;
			bullet.SetActive(true);
			smoke.SetActive(true);
			Instantiate(bullet, new Vector3(transform.position.x, transform.position.y, .2f), Quaternion.identity);
			bullet.SetActive(false);
			smoke.SetActive(false);
		}
	}
	
	void checkIfDead(){	//checks if the tank is dead and if it is it is destroyed
		if(hp < 1){
			Vector3 newTarget = Vector3.up;
			transform.LookAt(transform.position + new Vector3(0,0,1), newTarget);
			if(dying == 40){
				
				animator.SetTrigger("die");
			}
			
			dying -= 1;
			if(dying < 1){
				Destroy(gameObject);
				
			}
		}
	}
}
